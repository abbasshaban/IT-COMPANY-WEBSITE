const express = require('express');
const app = express();
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

app.post('/upload', upload.single('image'), (req, res) => {
  const image = req.file;
  // Process the image (e.g., store it in a database or file system)
  res.json({ imageUrl: `uploads/${image.filename}` });
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});


