<?php
$targetDir = 'uploads/';
if (!file_exists($targetDir)) {
  mkdir($targetDir, 0777, true);
}

$targetFile = $targetDir . basename($_FILES['image']['name']);

if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
  $response = array('imageUrl' => $targetFile);
  echo json_encode($response);
} else {
  echo json_encode(array('error' => 'Error uploading file'));
}
?>
