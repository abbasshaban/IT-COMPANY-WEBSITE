


<?php
// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Insert data into database
$sql = "INSERT INTO messages (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Message sent successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>



function doGet(e) {
    return handleResponse(e);
}

function doPost(e) {
    return handleResponse(e);
}

function handleResponse(e) {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var name = e.parameter.name;
    var email = e.parameter.email;
    var subject = e.parameter.subject;
    var message = e.parameter.message;
    
    sheet.appendRow([name, email, subject, message]);
    
    return ContentService.createTextOutput("Message sent successfully!");
}

Form Update

<form action="https://script.google.com/macros/d/your_script_id/exec" method="post">
    <!-- Your form fields here -->
    <button type="submit">Send Message</button>
</form>

Remember to replace placeholders with your actual database credentials, Google Sheets script ID, or other relevant details. Ensure proper security measures, such as validation and sanitization, to protect your database or Google Sheets from potential threats.